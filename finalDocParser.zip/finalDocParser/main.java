import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.geometry.Pos;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;
import javafx.stage.FileChooser;
import java.io.File;
import java.util.Scanner;

public class Main extends Application 
{ 
  
  @Override
  public void start(Stage primaryStage) {
    
    Label label; 
    Button button;
    VBox vbox;
    Scene scene;
    
    label = new Label("Choose A text document");
    button = new Button("Click"); 
    FileChooser fileChooser = new FileChooser();
    
    button.setLayoutX(50);
    button.setOnAction(new EventHandler<ActionEvent>() {
      @Override public void handle(ActionEvent e) {
        File file = fileChooser.showOpenDialog(primaryStage);
        Scanner doc = new Scanner(file);
        int numLines = 0;
        int numWords = 0;
        int numChar = 0;
        while(doc.hasNextLine()){
          String curLine = doc.nextLine();
          int size = curLine.length();
          boolean foundDiv = true;
          boolean foundChar = false;
          for(int i = 0; i < size; i++){
            if(curLine.charAt(i) == ' '){
              foundDiv = true;
              foundChar = false;
            }else{
              foundChar = true;
              numChar++;
            }
            if(foundChar && foundDiv){
              numWords++;
              foundDiv = false;
            }
          };
          numLines++;
        };
        doc.close();
        String output1 = String.format("Number of lines is: %s", numLines);
        String output2 = String.format("Number of Words is: %s", numWords);
        String output3 = String.format("Number of Char is: %s", NumChar);
        Stage stage = new Stage();
        line1 = new Label(output1);
        line2 = new Label(output2);
        line3 = new Label(output3);
        VBox root = new VBox(line1, line2, line3);
        root.setSpacing(20);
        root.setAlignment(Pos.CENTER);
        Scene page = new Scene(root, 500, 200);
        stage.setTitle("Process Output");
        stage.setScene(page);
        stage.show();
      }
    });

    vbox = new VBox(label, button);
    vbox.setSpacing(50);
    vbox.setAlignment(Pos.CENTER);
    scene = new Scene(vbox, 800, 200);
    
    primaryStage.setTitle("Txt Document parser");
    primaryStage.setScene(scene);
    primaryStage.show();
  } 
    
  public static void main(String[] args) {
    launch(args);
  }
} 